from PyQt5 import QtCore

MODEL_DATA_ROLE = QtCore.Qt.UserRole + 1
