 #!/bin/sh

python ./main.py